import React from "react"
export default function Footer() {
    return (
        <footer>
            <div className="inner">
                <p>2022 DCODELAB &copy; ALL RIGHT RESERVED</p>
            </div>
        </footer>
    )
}