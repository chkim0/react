import Anime from "../../asset/Anime"
import React, {useRef} from "react"


const btn = {
    position: 'absolute',
    top: 120,
    left: 100, 
}



export default function Visual() {

    const box = useRef(null);


    return (
        <figure id="visual" className="myScroll">
            <button
              style ={btn}
              onClick={()=>{
                new Anime(window,{
                    prop: 'scroll',
                    value : 1000,
                    duration : 500,
                    
                })
              }} >button</button>
            <div className='box'ref={box}></div>
        </figure>
    )
}